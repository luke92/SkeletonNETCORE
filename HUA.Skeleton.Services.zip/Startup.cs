//Using que vienen por defecto al crear WEBAPI
using System;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

// Using agregados
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using HUA.Skeleton.Business;

// Using de CORE
using HUA.Core.DataContext;
using HUA.Core.Interfaces;
using HUA.Core.Modules;
using HUA.Core.Settings;

// Using de Business
using HUA.Skeleton.Business.Modules.User;
using HUA.Skeleton.Business.Services.Seguridad;

//using de Data
using HUA.Skeleton.Data;
using Microsoft.Extensions.Caching.Memory;

namespace $safeprojectname$
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors(o => o.AddPolicy("MyPolicy", builder =>
            {
                builder.AllowAnyOrigin()
                    .AllowAnyMethod()
                    .AllowAnyHeader()
                    .AllowCredentials();
            }));

            // Context
            services.AddHttpContextAccessor();
            services.AddDbContext<Context>(
                options => options.UseSqlServer(Configuration["ConnectionStrings:Connection"])
            );

            services.AddDbContext<ActivityLoggerContext>(
                options => options.UseSqlServer(Configuration["ConnectionStrings:ActivityLoggerConnection"])
            );

            // Services
            services.AddScoped<ISeguridadService, SeguridadService>();

            // Settings
            services.Configure<SecuritySettings>(Configuration.GetSection("Security"));
            services.Configure<AuthenticationSettings>(Configuration.GetSection("Authentication"));

            // Modules
            services.AddScoped<UserModule>();
            services.AddScoped<IActivityLogger, ActivityLoggerModule>();

            services.AddMvc()
                .SetCompatibilityVersion(CompatibilityVersion.Version_2_1)
                .AddXmlSerializerFormatters();

            services.AddMemoryCache();

            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                .AddJwtBearer(options =>
                    options.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuer = true,
                        ValidateAudience = true,
                        ValidateLifetime = true,
                        ValidateIssuerSigningKey = true,
                        ValidIssuer = Configuration["JWT:Issuer"],
                        ValidAudience = Configuration["JWT:Audience"],
                        IssuerSigningKey = new SymmetricSecurityKey(
                            Encoding.UTF8.GetBytes(Configuration["JWT:Secret"])),
                        ClockSkew = TimeSpan.Zero
                    });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app,
                    IHostingEnvironment env,
                    ILoggerFactory loggerFactory,
                    IServiceProvider svp,
                    Context context,
                    IMemoryCache memoryCache,
                    IOptions<SecuritySettings> securitySettings,
                    ISeguridadService seguridadService)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseCors("MyPolicy");
            }
            else
            {
                app.UseCors("MyPolicy");// Hasta ver como solucionar que no se use esto en politicas usarlo tambien en productivo
            }

            app.UseMvc();

            // Config AutoMapper
            BusinessInitializer.InitializeMappings();

            // Ensure database was created
            BusinessInitializer.InitializeDatabase(context);

            // register application at seguridad
            BusinessInitializer.RegisterApplicationInSecurityServer(securitySettings.Value, seguridadService);

            // Seed data 
            BusinessInitializer.SeedDatabaseWithExamplesAsync(context);
        }
    }
}
