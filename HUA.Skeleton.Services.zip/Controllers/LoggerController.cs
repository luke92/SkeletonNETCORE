﻿using System;
using HUA.Core.Filters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace $safeprojectname$.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ActivityLoggerActionFilter]
    [AllowAnonymous]
    public class LoggerController : ControllerBase
    {

        [HttpPut]
        [HttpPost]
        public IActionResult Post(Object error)
        {
            return Ok("Success");
        }

    }
}
