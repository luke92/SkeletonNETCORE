﻿using System;
using HUA.Skeleton.Business.Modules.User;
using HUA.Core.Filters;
using HUA.Core.Models;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace $safeprojectname$.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ActivityLoggerActionFilter]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class UserController : ControllerBase
    {
        private readonly UserModule _userModule;
        public UserController(UserModule userModule)
        {
            _userModule = userModule;
        }

        [HttpGet("{id}")]
        public IActionResult Get(Guid userId)
        {
            var operationResult = _userModule.GetItem(userId);

            if (operationResult.Result != OperationResult.Ok)
                return StatusCode(422, operationResult);

            return Ok(operationResult);
        }

        [HttpGet]
        [AllowAnonymous]
        public IActionResult Get()
        {
            var operationResult = _userModule.GetPage();

            if (operationResult.Result != OperationResult.Ok)
                return StatusCode(422, operationResult);

            return Ok(operationResult);
        }
    }
}