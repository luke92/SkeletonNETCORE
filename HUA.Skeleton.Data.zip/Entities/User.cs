﻿using HUA.Core.Entities;

namespace $safeprojectname$.Entities
{
    public class User : HUAEntity
    {

        public string Name { get; set; }

        public string SurName { get; set; }

        public string Rol { get; set; }

        public string Description { get; set; }


    }
}

