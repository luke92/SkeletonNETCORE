﻿using $safeprojectname$.Entities;
using Microsoft.EntityFrameworkCore;

namespace $safeprojectname$
{
    public class Context : DbContext
    {
        public Context()
        { }

        public Context(DbContextOptions<Context> options)
            : base(options)
        { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>().ToTable("users");
        }

        public DbSet<User> User { get; set; }

    }
}
