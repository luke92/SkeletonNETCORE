﻿using Xunit;

namespace $safeprojectname$.Integration
{
    public class ExampleTest
    {

        [Fact]
        public void Obtiene_token_autenticacion()
        {
            // Given

            // When

            // Then
        }

    }
}
