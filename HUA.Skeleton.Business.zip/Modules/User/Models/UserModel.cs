﻿using System;

namespace $safeprojectname$.Modules.User.Models
{
    public class UserModel : GenericModel
    {
        public string Name { get; set; }

        public string SurName { get; set; }

        public string Rol { get; set; }

        public string Description { get; set; }
    }
}
