﻿using System;
using System.Collections.Generic;
using System.Linq;
using $safeprojectname$.Modules.User.Models;
using HUA.Core.Models;
using HUA.Core.Modules;
using HUA.Skeleton.Data;

namespace $safeprojectname$.Modules.User
{
    public class UserModule : CrudModule<Context, Data.Entities.User, UserModel>
    {
        private readonly Context _context;
        public UserModule(Context context) : base(context)
        {
            _context = context;
            QueryableBase = context.Set<Data.Entities.User>()
                .AsQueryable();
        }

        protected override IEnumerable<ErrorModel> CheckCreateValidations(UserModel model)
        {
            throw new NotImplementedException();
        }

        protected override IEnumerable<ErrorModel> CheckDeleteValidations(Guid model)
        {
            throw new NotImplementedException();
        }

        protected override IEnumerable<ErrorModel> CheckUpdateValidations(UserModel model)
        {
            throw new NotImplementedException();
        }
    }
}
