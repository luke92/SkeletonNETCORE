﻿using System.Threading.Tasks;
using HUA.Core.Models;
using HUA.Core.Settings;

namespace $safeprojectname$.Services.Seguridad
{
    public interface ISeguridadService
    {
        void Register(SecuritySettings settings);
    }
}
