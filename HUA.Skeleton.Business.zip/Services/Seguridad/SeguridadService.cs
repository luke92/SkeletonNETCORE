﻿using System;
using System.Net.Http;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Http.Extensions;
using System.Threading.Tasks;
using HUA.Core.Models;
using HUA.Core.Settings;
using Newtonsoft.Json;

namespace $safeprojectname$.Services.Seguridad
{
    public class SeguridadService : ISeguridadService
    {
        public async void Register(SecuritySettings settings)
        {
            Console.WriteLine($"Settings:\n Codigo: {settings.Codigo}\n Register Uri: {settings.RegistrationUri}");
            using (HttpClient client = new HttpClient())
            {
                var appData = new RegistrationModel
                {
                    Codigo = settings.Codigo,
                    Perfiles = settings.Perfiles
                };

                HttpResponseMessage response = await PostAsJsonAsync(client,settings.RegistrationUri, appData);

                if (!response.IsSuccessStatusCode)
                {
                    var error = await response.Content.ReadAsStringAsync();

                    throw new ApplicationException(
                        $"An error ocurred trying to register application at security server.\n" +
                        $"Server: '{settings.RegistrationUri}'\n" +
                        $"Code: '{settings.Codigo}'\n" +
                        $"Profiles: '{String.Join(", ", settings.Perfiles)}'\n" +
                        $"Error Code: '{response.StatusCode}'\n" +
                        $"Error Message: '{response.ReasonPhrase}'\n" +
                        $"Error Description: '{error}'"
                    );
                }
            }
        }
        private static Task<HttpResponseMessage> PostAsJsonAsync<T>(
            HttpClient httpClient, string url, T data)
        {
            var dataAsString = JsonConvert.SerializeObject(data);
            var content = new StringContent(dataAsString);
            content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
            return httpClient.PostAsync(url, content);
        }

    }
}
