﻿using System;
using HUA.Core.Models;

namespace $safeprojectname$
{
    public abstract class GenericModel : IEntityModel
    {
        public Guid Id { get; set; }
        public string CreatedDate { get; set; }
        public string UpdateDate { get; set; }
    }
}
