﻿using System.Collections.Generic;
using AutoMapper;
using $safeprojectname$.Modules.User.Models;
using $safeprojectname$.Services.Seguridad;
using HUA.Core.Settings;
using HUA.Skeleton.Data;
using HUA.Skeleton.Data.Entities;
using Microsoft.EntityFrameworkCore.Internal;

namespace $safeprojectname$
{
    public class BusinessInitializer
    {
        public static object thisLock = new object();

        public static void InitializeDatabase(Context context)
        {
            // ensure database exists
            context.Database.EnsureCreated();
            
        }

        public static void InitializeMappings()
        {
            lock (thisLock)
            {
                Mapper.Reset();
                Mapper.Initialize(cfg =>
                {
                    cfg.CreateMap<User, UserModel>().ReverseMap();

                });
            }
        } 

        public static void RegisterApplicationInSecurityServer(SecuritySettings settings, ISeguridadService registerSeguridadService)
        {
            registerSeguridadService.Register(settings);
        }

        public static void SeedDatabaseWithExamplesAsync(Context context)
        {
            if (!context.User.Any())
            {
                List<User> users = new List<User>()
                {
                    new User(){ Name = "Juan", SurName = "Garcia", Rol = "Administrador", Description = "orem ipsum dolor sit amet, consectetur adipiscing elit. Ut a lorem nec arcu ultrices convallis."},
                    new User(){ Name = "Pedro", SurName = "Sanchez", Rol = "Tecnología y Sistemas", Description = "Mauris mollis ante quis metus euismod elementum. Quisque sit amet venenatis lectus, ut tincidunt mi. In ornare urna sit amet mollis hendrerit. "},
                    new User(){ Name = "Carla", SurName = "Alvarez", Rol = "Finanzas", Description = "Integer scelerisque mi felis, at fermentum lacus tempus at. Fusce vel lectus et sem semper aliquam"},
                    new User(){ Name = "Maria", SurName = "Fernandes", Rol = "RRHH", Description = "Vestibulum sit amet sem non quam convallis condimentum."},
                    new User(){ Name = "Esteban", SurName = "Garcia", Rol = "RRHH", Description = "Mauris vitae libero lectus. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. In ac efficitur velit. Curabitur molestie nulla at libero pharetra ullamcorper."},
                    new User(){ Name = "Nicolas", SurName = "Tesla", Rol = "Tecnología y Sistemas", Description = "Phasellus tortor sapien, ultricies a vehicula id, imperdiet vitae massa. Nunc nisl nisi, gravida id consequat eget, aliquam id ipsum. Fusce at urna massa."}
                };

                context.User.AddRange(users);
                context.SaveChanges();
            }

        }

    }
}
