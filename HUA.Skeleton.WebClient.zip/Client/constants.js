﻿export default {
    RolesKeys: {
        SystemAdministrator: 'SystemAdministrator'
    },
    Roles: [
        { rol: 'DEF.Administrador', description: 'Administrador del Sistema' }
    ],
    Defaults: {
        PageSize: 10
    },    
    Entities: {
        TipoDeDocumento: 'tipoDeDocumento',
        User: 'user',
        Logger: 'logger'
    },
    FetchStatus: {
        Pristine: 'pristine',
        Fetching: 'fetching',
        Loaded: 'loaded',
        Error: 'error'
    },
    MessageTypes: {
        None: 'none',
        Error: 'error',
        Info: 'info',
        Warning: 'warning',
        Success: 'success'
    },
    ActionTypes: {
        LOGIN_STARTED: 'login-started',
        LOGIN_AUTO: 'login-auto',
        LOGIN_SUCCED: 'login-succed',
        LOGIN_FAILED: 'login-failed',
        LOGOUT: 'logout',

        MESSAGER_CLOSE: 'messager-close',
        MESSAGER_SHOW_ERROR: 'messager-show-error',
        MESSAGER_SHOW_INFO: 'messager-show-info',
        MESSAGER_SHOW_WARNING: 'messager-show-warning',
        MESSAGER_SHOW_SUCCESS: 'messager-show-success',

        FETCH_PAGE_STARTED: function (entity) { return 'fetch-page-' + entity + '-started' },
        FETCH_PAGE_SUCCEED: function (entity) { return 'fetch-page-' + entity + '-succeed' },
        FETCH_PAGE_FAILED: function (entity) { return 'fetch-page-' + entity + '-failed' },

        FETCH_BY_ID_STARTED: function (entity) { return 'fetch-by-id-' + entity + '-started' },
        FETCH_BY_ID_SUCCEED: function (entity) { return 'fetch-by-id-' + entity + '-succeed' },
        FETCH_BY_ID_FAILED: function (entity) { return 'fetch-by-id-' + entity + '-failed' },

        CREATE_STARTED: function (entity) { return 'create-' + entity + '-started' },
        CREATE_SUCCEED: function (entity) { return 'create-' + entity + '-succeed' },
        CREATE_FAILED: function (entity) { return 'create-' + entity + '-failed' },

        UPDATE_STARTED: function (entity) { return 'update-' + entity + '-started' },
        UPDATE_SUCCEED: function (entity) { return 'update-' + entity + '-succeed' },
        UPDATE_FAILED: function (entity) { return 'update-' + entity + '-failed' },

        DELETE_STARTED: function (entity) { return 'delete-' + entity + '-started' },
        DELETE_SUCCEED: function (entity) { return 'delete-' + entity + '-succeed' },
        DELETE_FAILED: function (entity) { return 'delete-' + entity + '-failed' },
    }
}