import { executeApiCall } from '../api/apiProxy';

const UserActions = {

    fetchPageAction: function () {
        return dispatch => {
            return new Promise((resolve, reject) => {
                executeApiCall('User', 'GET')
                    .then(
                        (response) => {
                            resolve(response);
                        },
                        (response) => {
                            reject(response);
                        }
                    );
            });
        }
    },
    fetchByIdAction: function (userId) {
        return dispatch => {
            return new Promise((resolve, reject) => {
                executeApiCall('User/' + userId, 'GET')
                    .then(
                        (response) => {
                            resolve(response);
                        },
                        (response) => {
                            reject(response);
                        }
                    );
            });
        }
    }
};
export default UserActions;
