import Constants from '../constants';
import CreateCrudApi from '../factories/crudApiFactory';
import {
    createActionFactory
} from '../factories/crudActionsFactory';

const entityCrudApi = CreateCrudApi(Constants.Entities.Logged);

const LoggedActions = {
    createAction: createActionFactory(Constants.Entities.Logged, entityCrudApi)
};

export default LoggedActions;