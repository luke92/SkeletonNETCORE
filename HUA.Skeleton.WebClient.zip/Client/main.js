﻿import React from '../../../../../Users/MROJO/AppData/Local/Microsoft/TypeScript/2.9/node_modules/@types/react';
import { render } from '../../../../../Users/MROJO/AppData/Local/Microsoft/TypeScript/2.9/node_modules/@types/react-dom';
import { Provider, connect } from '../../../../../Users/MROJO/AppData/Local/Microsoft/TypeScript/2.9/node_modules/@types/react-redux';

import Constants from './constants';
import store from './store';
import MainLayout from './pages/layout/mainLayout';


if (module.hot && process.env.NODE_ENV == 'development') {
    module.hot.accept();
}

// if local storage has an auth token, lets validate it and re login user
// Hacemos uso de un token estático hasta que esté finalizada la nueva autenticación de Seguridad
//if (localStorage.authToken) {
var token =
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IlNrZWxldG9uIiwiaHR0cDovL3NjaGVtYXMubWljcm9zb2Z0LmNvbS93cy8yMDA4LzA2L2lkZW50aXR5L2NsYWltcy9leHBpcmF0aW9uIjoxfQ.xsKMCPfjpVsvhVvXnQBWClyKnhyw7C6lW9q4X7iquRk";
    store.dispatch({ type: Constants.ActionTypes.LOGIN_AUTO, payload: { token: token} });
//}


// render application
render(<Provider store={store}>
        <MainLayout />
</Provider>, document.getElementById('app'));

