﻿import { executeApiCall } from '../api/apiProxy';

/* This constructor function generates the default api methods interface
    required to perform getAll, getById and save operations on a given backend.
    It receives the plural and singular names of the entity */
export default function (singularEntityName) {
    return {
        getPage(page, pageSize, filter, orderBy) {
            let orderByAux = orderBy;
            if ( Array.isArray(orderBy) ){
                orderByAux = "";
                for (let index = 0; index < orderBy.length; index++) {
                    const element = orderBy[index];
                    orderByAux += element.value + element.key;
                    // If it is not the last element
                    if(index < orderBy.length -1){
                        orderByAux += ","
                    }
                }
            }
            return executeApiCall(`${singularEntityName}?page=${page}&pageSize=${pageSize}&${filter || ''}&orderBy=${orderByAux || ''}`, 'GET');
        },

        getById(id) {
            return executeApiCall(`${singularEntityName}/${id}`, 'GET');
        },

        create(model) {
            return executeApiCall(`${singularEntityName}`, 'POST', model);
        },

        update(model) {
            return executeApiCall(`${singularEntityName}/${model.Id}`, 'PUT', model);
        },

        delete(model) {
            return executeApiCall(`${singularEntityName}/${model.Id}`, 'DELETE');
        }
    }
}