﻿let SUBDIRECTORIO = document.getElementsByTagName('base')[0].getAttribute("href");


const API_URL_ESTRUCTURA = document.getElementsByTagName('DefaultService')[0].getAttribute("href");
export const API_URL_SEGURIDAD = document.getElementsByTagName('SeguridadService')[0].getAttribute("href");

// this function returns the base common request
// configuration required to hit the api
function getRequestConfig(requestMethod, model) {
    // create request configuration for requested method
    let config = {
        headers: {
            "Access-Control-Allow-Origin": "*",
            'Content-Type': 'application/json'
        },
        method: requestMethod
    };

    // check if session token exists
    let token = localStorage.authToken;
    if (token) {
        config.headers['Authorization'] = `Bearer ${token}`;
    }
    else {
        delete config.headers['Authorization'];
    }

    // attach model to request body if defined
    if (model) {
        config.body = JSON.stringify(model);
    }

    return config;
}

// this function handles api response checking
// if response if succesfull or not
function handleResponse(response) {
    let status = response.status;

    // If status is forbidden, redirect to Login & return nothing,
    // indicating the end of the Promise chain
    if (status === 401 || status === 403) {
        localStorage.removeItem("authToken");
        window.location.href = "login";
    }
    
    // If call was not 
    return response.json()
        .then(json => {
            // If status is success, return a JSON Promise
            if (status >= 200 && status < 300) {
                return Promise.resolve(json);
            }

            if (status == 422) {
                return Promise.reject(json);
            }

            // print warning to console for development debugging
            console.warn(json);
            // reject promise with connectivity error
            return Promise.reject({ Errors: [{ source: 'Connection', Message: 'Ocurrio un error intentando obtener los datos. Vuelva a intentarlo luego o si el problema persiste contacte al administrador del sistema.' }] });
        }, error => {
            if (status <= 500 || status < 600) {
                return Promise.reject({ Errors: [{ source: 'Server', Message: 'Error interno del servidor.' }] });
            }

            return Promise.reject({ Errors: [{ source: 'Connection', Message: 'Ocurrio un error intentando obtener los datos. Vuelva a intentarlo luego o si el problema persiste contacte al administrador del sistema.' }] });
        })
}

export function executeApiCall(methodUrl, type, model, url) {


    if (url == null) url = API_URL_ESTRUCTURA

    return fetch(`${url}/${methodUrl}`, getRequestConfig(type, model))
        .then(r => handleResponse(r));
}

export function executeApiCallEstrcutura(methodUrl, type, model) {
    return fetch(`${API_URL_ESTRUCTURA}/${methodUrl}`, getRequestConfig(type, model))
        .then(r => handleResponse(r));
}