﻿import { combineReducers } from '../../../../../../Users/MROJO/AppData/Local/Microsoft/TypeScript/2.9/node_modules/redux';

import authenticationReducer from "./authenticationReducer";
import messagerReducer from "./messagerReducer";

export default combineReducers({
    authentication: authenticationReducer,
    messager: messagerReducer
});