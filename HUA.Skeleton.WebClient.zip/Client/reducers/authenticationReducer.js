﻿import jwt_decode from '../../../../../../Users/MROJO/AppData/Local/Microsoft/TypeScript/2.9/node_modules/@types/jwt-decode';
import Constants from '../constants';

var defaultState = {
    isAuthenticated: false,
    fetchStatus: Constants.FetchStatus.Pristine,
    Errors: [],
    token: null
};

/**
 * this function cleans up the claim type identificator
 * removing all the address portion, leaving only the key name
 */
function cleanUpClaimType(claimType) {
    var claimArr = claimType.split('/');
    return claimArr[claimArr.length - 1];
}

export default function (state = defaultState, action) {
    var newState = { ...state };

    switch (action.type) {
        // if user login succed, let's store user information
        case Constants.ActionTypes.LOGIN_AUTO:
        case Constants.ActionTypes.LOGIN_SUCCED:
            // add auth token to local browser storage
            localStorage.setItem("authToken", action.payload.token);

            // lets decode received token information
            let tokenInformation = jwt_decode(action.payload.token);
            
            console.log(tokenInformation);

            // and get cleaned up claims information for the user information
            let userInformation = {};
            for (var key in tokenInformation) {
                userInformation[cleanUpClaimType(key)] = tokenInformation[key];
            }
;
            // if only one role is there, lets unify it as an array
            if (!Array.isArray(userInformation.role)) {
                var userRole = userInformation.role;
                userInformation.role = [userRole];
            }

            // update application state
            newState = Object.assign({}, newState, userInformation, {
                isAuthenticated: true,
                idleInMinutes:  parseInt(userInformation['expiration']),
                Errors: [],
                fetchStatus: Constants.FetchStatus.Loaded
            });


            break;

        // any other case, user information is null
        case Constants.ActionTypes.LOGIN_FAILED:
            // update application state
            localStorage.removeItem("authToken");
            localStorage.removeItem("name");
            localStorage.removeItem("avatar");
            newState = Object.assign({}, newState, userInformation, {
                isAuthenticated: false,
                idleInMinutes: 0,
                Errors: Array.isArray(action.payload.Errors) ? action.payload.Errors : [action.payload.Errors],
                fetchStatus: Constants.FetchStatus.Error,
                token: null
            });
            break;

        case Constants.ActionTypes.LOGIN_STARTED:
            // update application state
            localStorage.removeItem("authToken");
            localStorage.removeItem("name");
            localStorage.removeItem("avatar");
            newState = Object.assign({}, newState, userInformation, {
                isAuthenticated: false,
                idleInMinutes: 0,
                Errors: [],
                fetchStatus: Constants.FetchStatus.Fetching,
                token: null
            });
            break;

        case Constants.ActionTypes.LOGOUT:
            localStorage.removeItem("authToken");
            localStorage.removeItem("name");
            localStorage.removeItem("avatar");
            localStorage.removeItem("expiration");
            newState = {
                token: null
            };
    }

    return newState;
}