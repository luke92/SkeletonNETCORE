import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { fetchByIdAction, fetchPageAction } from '../../actions/userActions';
import { showError } from '../../actions/messageActions';
import LoadingContainer from '../../components/loading';



class UserPage extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            user: null,
            loading: true
        }
    }

    // Carga desde BE el nodo segun el idNodo de la versión pasada
    loadUser(userId){
        this.props.fetchUserByNode(userId)
            .then(response => {
                this.setState({ user: response.data[0], loading: false });
            })
            .catch(result => {
                this.setState({ loading: false });
                this.props.showError(result.errors);
            });
    }
    
    
    render() {
        if (!this.props.authentication.isAuthenticated) {
            this.props.history.push("login");
        }

        const { classes } = this.props;
        const { user, loading } = this.state;
        
        return (
                <div>
                <div>{!loading &&
                    <LoadingContainer></LoadingContainer>}
                </div>
                    <div>User secret page</div>
                </div>
        );
    };
};

UserPage.propTypes = {
    classes: PropTypes.object.isRequired,
    showError: PropTypes.func.isRequired
}

export default connect(
    state => {
        return {
            authentication: state.authentication
        };
    },
    {
        showError: showError,
        fetchPage: fetchPageAction,
        fetchUserByNode: fetchByIdAction
    }
)(UserPage);