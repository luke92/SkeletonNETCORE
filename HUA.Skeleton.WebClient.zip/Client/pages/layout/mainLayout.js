﻿import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import PrivateLayout from './privateLayout';
import Messager from '../../components/messager';
import { closeMessager } from '../../actions/messageActions';
import { BrowserRouter as Router } from 'react-router-dom';

import LoggedActions from '../../actions/LoggedActions';


class MainLayout extends React.Component {

    // Catch Errors
    componentDidCatch(error, errorInfo) {
        // You can also log the error to an error reporting service
        console.log(error);
        console.log(errorInfo);

        this.props.storeLogged({name: 'ReactJs', details: errorInfo});

        window.location.href = 'error';
    }

    render() {
        const { messager, closeMessager } = this.props;
        return <Router>
                    <div>
                        <Messager
                            open={messager.open}
                            messages={messager.messages}
                            messageType={messager.type}
                            closeHandler={closeMessager}
                        />
                        {<PrivateLayout />}
                    </div>
                </Router>
    }
}

MainLayout.propTypes = {
    authentication: PropTypes.object.isRequired,
    storeLogged: PropTypes.func.isRequired
}

export default connect(
    state => {
        return {
            authentication: state.authentication,
            messager: state.messager
        }
    },
    {
        closeMessager: closeMessager,
        storeLogged: LoggedActions.createAction
    }
)(MainLayout);