﻿import React from '../../../../../../Users/MROJO/AppData/Local/Microsoft/TypeScript/2.9/node_modules/@types/react';
import PropTypes from '../../../../../../Users/MROJO/AppData/Local/Microsoft/TypeScript/2.9/node_modules/@types/prop-types';

import { Modal } from '../../../../../../Users/MROJO/AppData/Local/Microsoft/TypeScript/2.9/node_modules/@types/react-bootstrap';
import { Button } from '../../../../../../Users/MROJO/AppData/Local/Microsoft/TypeScript/2.9/node_modules/@types/react-bootstrap';
import IdleTimer from 'react-idle-timer';

class Idle extends React.Component {

    constructor() {

        super();

        this.state = {
            open: false,
            timerId: null
        };

        this.idleTimer = null;
        this.onIdle = this._onIdle.bind(this);
        this.timer = this.timer.bind(this);
    }

    componentDidMount() {

        this.setState({ timeLeft: this.props.secondsToAction });
    }

    timer() {
        if (this.state.timeLeft == 1) {
            this.handleClose();
        } else {
            this.setState({ timeLeft: this.state.timeLeft - 1 });
        }
    }

    _onIdle(e) {
        this.setState({ open: true, timerId: setInterval(this.timer, 1000) });
    }

    clearTimer() {
        this.setState({ open: false, timeLeft: this.props.secondsToAction });
        clearInterval(this.state.timerId);
    }

    handleClose = () => {
        this.clearTimer();
        this.props.logoutAction();
    };

    handleNext = () => {
        this.clearTimer();
    };

    render() {

        const { timeLeft } = this.state;
        const { minutesToIdle } = this.props;

        return (
            <div>
                <IdleTimer ref={ref => { this.idleTimer = ref }}
                    element={document}
                    onIdle={this.onIdle}
                    timeout={1000 * 60 * minutesToIdle}>
                    <Modal show={this.state.open}>
                        <Modal.Header closeButton>
                            <Modal.Title>Tiempo de inactividad</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            <p>Se ha detectado que no has tenido actividad en la web desde hace {minutesToIdle} minutos.
                                <br></br>¿Desea continuar conectado? Tienes <b> {timeLeft} </b> segundos para tomar una acción.
                            </p>
                        </Modal.Body>
                        <Modal.Footer>
                            <Button bsStyle="danger" onClick={this.handleClose}>Cerrar Sesión</Button>
                            <Button bsStyle="link" onClick={this.handleNext}>Continuar</Button>
                        </Modal.Footer>
                    </Modal>
                </IdleTimer>
            </div>
        );
    }
}

Idle.propTypes = {
    secondsToAction: PropTypes.number.isRequired,
    minutesToIdle: PropTypes.number.isRequired,
    logoutAction: PropTypes.func.isRequired
};

export default Idle