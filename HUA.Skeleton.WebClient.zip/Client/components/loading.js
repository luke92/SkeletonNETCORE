import React from 'react';
import { withStyles } from '@material-ui/core/styles';

const styles = theme => ({
    loading:{
        width: "100%",
        height: "100%"
    }
});

class LoadingContainer extends React.Component {
    
    render() {
        const { classes } = this.props;
        return (
            <center className={classes.loading}><img src="static/images/loading.gif" /></center>
        );
    }
}

export default withStyles(styles)(LoadingContainer);