﻿import React from '../../../../../../Users/MROJO/AppData/Local/Microsoft/TypeScript/2.9/node_modules/@types/react';
import PropTypes from '../../../../../../Users/MROJO/AppData/Local/Microsoft/TypeScript/2.9/node_modules/@types/prop-types';

import { ToastContainer, toast, ToastType } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import constants from '../constants';


class Messager extends React.Component {
    
    getToastType(type){

        switch (type) {
            case constants.MessageTypes.Success:
                return toast.TYPE.SUCCESS;
                break;
            case constants.MessageTypes.INFO:
                return toast.TYPE.INFO;
                break;
            case constants.MessageTypes.WARNING:
                return toast.TYPE.WARNING;
                break;
            case constants.MessageTypes.Error:
                return toast.TYPE.ERROR;
                break;
            case constants.MessageTypes.INFO:
                return toast.TYPE.INFO;
                break;
            default:
                return toast.TYPE.DEFAULT;
                break;
        }
    }

    render() {
        const { messageType, messages, classes } = this.props;

        messages.forEach(message => {
            toast(message.message, { type: this.getToastType(message.type) });
        });

        return (

            <ToastContainer
                position="bottom-center"
                autoClose={15000}
                hideProgressBar={false}
                newestOnTop
                closeOnClick
                rtl={false}
                pauseOnVisibilityChange
                draggable
                pauseOnHover
            />
                
        );
    }
}

Messager.propTypes = {
    messageType: PropTypes.oneOf(['none', 'success', 'warning', 'error', 'info']).isRequired,
    messages: PropTypes.array.isRequired,
    open: PropTypes.bool.isRequired,
    closeHandler: PropTypes.func.isRequired
}

export default (Messager);