import React from 'react';


import { withStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import Button from '@material-ui/core/Button';

import 'react-sortable-tree/style.css'; 
import SortableTree, { toggleExpandedForAll } from 'react-sortable-tree';

 
const styles = theme => ({
    graph: {
        height: "calc( 100vh - 200px)"
    },
    topMenu: {
        background: '#f2f5f8',
        width: '100%',
        padding: '5px 10px',
        borderBottom: 'solid 1px lightgrey'
    },
    buttonMenu: {
        padding: '3px 8px',
        minHeight: 30,
        marginRight: 10
    }
});

class GraphContainer extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            treeData: [],
            open: false,
            searchQuery: null
        };
    }

    initTree(tree){
        return tree || [];
    }

    isEstructuraValid(estructura){
        return estructura != null
    }

    hasComponentes(estructura){
        return estructura.componentes && estructura.componentes.length > 0;
    }

    isComponenteRelacion(componente){
        // Los componentes relación son los únicos que no tienen idNodo
        return componente.idNodo == null;
    }

    buildNode(tree, estructura, children, relaciones){
        tree.push(Object.assign(
            {},
            estructura, 
            { 
                title: estructura.shortName || estructura.nombre || estructura.descripcion || 'Raíz', 
                expanded:true, 
                children: children, 
                relaciones: relaciones 
            }));
        return tree;
    }

    // Función para parsear el Json que viene del BE al utilizado por la librería
    parseJson(estructura, tree = null) {
        // Init
        var children = [];
        var relaciones = [];
        tree = this.initTree(tree);
        
        // Si la estructura es valida se procesa
        if( this.isEstructuraValid(estructura) ){
            // Si tiene componentes / hijos se deben procesar primero
            if( this.hasComponentes(estructura) ){
                // Analizamos cada componente
                for (let index = 0; index < estructura.componentes.length; index++) {
                    let single = estructura.componentes[index];
                    // Si el componente no tiene ID significa que es una relación
                    if ( !this.isComponenteRelacion(single) ){
                        // A cada uno lo parseo y lo agrego a children
                        this.parseJson( single, children );
                    }else{
                        // las relaciones se guardan en otra sección para acceder más rápido
                        relaciones.push(single.componente);
                    }
                }
            }
            // Agregamos el nodo y devolvemos el nuevo árbol
            return this.buildNode(tree, estructura, children, relaciones );
        }

        return tree;
        
    }

    // Solo renderizamos si no hay un json previo o el json es distinto al que tengo en memoria
    needUpdateProps(nextProps){
        return this.props.json == null || nextProps.json !== this.props.json;
    }

    // Evitamos cambiar las props y renderizar
    componentWillReceiveProps(nextProps) {
        if ( this.needUpdateProps(nextProps) ) {
            this.setState({ treeData: this.parseJson(nextProps.json)});
        }
    }

    // Es necesario montar si no hay un json previo o no hay treeData disponible en memoria
    needMount(){
        return this.props.json != null && this.state.treeData.length == 0;
    }

    // Evito cambiar los datos
    componentDidMount(){
        if ( this.needMount() ) {
            this.setState({ treeData: this.parseJson(this.props.json)});
        }
    }

    // Función ejecutada cuando se hace click en nodo para ver los detalles de la misma
    clickHandlerNode(node){
        if( this.props.clickHandler != undefined ){
            this.props.clickHandler(node);
        }
    }

    // Función ejecutada al terminar la búsqueda de nodos coincidentes por idNodo
    // Solo se devuelve el primero encontrado a una función del padre
    finishSearch(result){
        if ( result != null)
            this.props.finishsearch(result.node);
    }

    // Expande todos los nodos y sus hijos
    expand(){
        this.setState({
            treeData: toggleExpandedForAll({
              treeData: this.state.treeData,
              expanded: true
            })
          });
    }

    // Contrae todos los nodos y sus hijos
    colapse(){
        this.setState({
            treeData: toggleExpandedForAll({
              treeData: this.state.treeData,
              expanded: false
            })
          });
    }
    


    render() {
        const { classes } = this.props;
        

        return (
            <Grid  container className={classes.graph}>
                <Grid item className={classes.topMenu}>
                <Button className={classes.buttonMenu} variant="outlined" size="small" color="primary" onClick={() => this.expand()}>
                    Expandir
                </Button>
                <Button className={classes.buttonMenu} variant="outlined" size="small" color="primary" onClick={() => this.colapse()}>
                    Contraer
                </Button>
                </Grid>
                <Grid item style={{ height: '100%', width: '100%', overflow: "auto" }}>
                    <SortableTree
                        treeData={this.state.treeData}
                        onChange={treeData => this.setState({ treeData })}
                        canDrag={false}
                        searchFocusOffset={0}
                        searchMethod={({ node, searchQuery }) =>
                            searchQuery && node.idNodo == searchQuery.idNodo
                        }
                        searchQuery={this.props.search}
                        getNodeKey={({ node }) => node.idNodo}
                        searchFinishCallback={matches =>
                            this.finishSearch(matches[0])
                        }
                        generateNodeProps={rowInfo => ({
                            onClick: (event) => { 
                                
                                if( !(event.target.className.includes('collapseButton') || 
                                    event.target.className.includes('expandButton')) ) {
                                    this.clickHandlerNode(rowInfo.node);
                                }

                            }
                        })}
                        />
                </Grid>
            </Grid>
        );
    }
}

export default withStyles(styles)(GraphContainer);