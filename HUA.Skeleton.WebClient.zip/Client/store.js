﻿import { applyMiddleware, createStore } from '../../../../../Users/MROJO/AppData/Local/Microsoft/TypeScript/2.9/node_modules/redux';
import { createLogger } from '../../../../../Users/MROJO/AppData/Local/Microsoft/TypeScript/2.9/node_modules/@types/redux-logger';
import thunk from 'redux-thunk';
import reducer from './reducers';

const middleware = applyMiddleware(thunk, createLogger());
const store = createStore(reducer, middleware);

export default store;