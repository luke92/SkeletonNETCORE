#!/bin/bash

# Check arguments
if [ $# -eq 0 ]
  then
    echo "No arguments supplied. Specify a path to create the folders. "
	exit 1
fi

className=$1
path=$2

echo "copying files in $path..."
# Copy file
cp -rf ./src/utils/scaffolding/example "$path"

# -n -> silent
echo "Replacing class in file..."
# Replace 'example' by the correct class (lower case)
lowerCaseExample='example'
lowerCaseClassName=`echo ${className:0:1} | tr '[A-Z]' '[a-z]'`${className:1}

sed -i -e 's/example/'"${lowerCaseClassName}"'/g' "${path}/example/index.js"
sed -i -e 's/example/'"${lowerCaseClassName}"'/g' "${path}/example/ExampleComponent.jsx"
sed -i -e 's/example/'"${lowerCaseClassName}"'/g' "${path}/example/ExampleContainer.js"
sed -i -e 's/example/'"${lowerCaseClassName}"'/g' "${path}/example/duck/exampleActions.js"
sed -i -e 's/example/'"${lowerCaseClassName}"'/g' "${path}/example/duck/exampleOperations.js"
sed -i -e 's/example/'"${lowerCaseClassName}"'/g' "${path}/example/duck/exampleReducers.js"
sed -i -e 's/example/'"${lowerCaseClassName}"'/g' "${path}/example/duck/exampleTests.js"
sed -i -e 's/example/'"${lowerCaseClassName}"'/g' "${path}/example/duck/exampleTypes.js"
sed -i -e 's/example/'"${lowerCaseClassName}"'/g' "${path}/example/duck/index.js"

# Replace 'Example' by the correct class 
upperCaseExample='Example'
sed -i -e 's/Example/'"${className}"'/g' "$path/example/index.js"
sed -i -e 's/Example/'"${className}"'/g' "$path/example/ExampleComponent.jsx"
sed -i -e 's/Example/'"${className}"'/g' "$path/example/ExampleContainer.js"
sed -i -e 's/Example/'"${className}"'/g' "$path/example/duck/exampleActions.js"
sed -i -e 's/Example/'"${className}"'/g' "$path/example/duck/exampleOperations.js"
sed -i -e 's/Example/'"${className}"'/g' "$path/example/duck/exampleReducers.js"
sed -i -e 's/Example/'"${className}"'/g' "$path/example/duck/exampleTests.js"
sed -i -e 's/Example/'"${className}"'/g' "$path/example/duck/exampleTypes.js"
sed -i -e 's/Example/'"${className}"'/g' "$path/example/duck/index.js"

# Change name of files
echo "Changing file names..."

mv "${path}/example" "${path}/${lowerCaseClassName}"
mv "${path}/${lowerCaseClassName}/index.js" "${path}/${lowerCaseClassName}/index.js"
mv "${path}/${lowerCaseClassName}/ExampleComponent.jsx" "${path}/$lowerCaseClassName/${className}Component.jsx"
mv "${path}/${lowerCaseClassName}/ExampleContainer.js" "${path}/${lowerCaseClassName}/${className}Container.js"
mv "${path}/${lowerCaseClassName}/duck/exampleActions.js" "${path}/${lowerCaseClassName}/duck/${className}Actions.js"
mv "${path}/${lowerCaseClassName}/duck/exampleOperations.js" "${path}/${lowerCaseClassName}/duck/${className}Operations.js"
mv "${path}/${lowerCaseClassName}/duck/exampleReducers.js" "${path}/${lowerCaseClassName}/duck/${className}Reducers.js"
mv "${path}/${lowerCaseClassName}/duck/exampleTests.js" "${path}/${lowerCaseClassName}/duck/${className}Tests.js"
mv "${path}/${lowerCaseClassName}/duck/exampleTypes.js" "${path}/${lowerCaseClassName}/duck/${className}Types.js"
mv "${path}/${lowerCaseClassName}/duck/index.js" "${path}/${lowerCaseClassName}/duck/index.js"


#print variable on a screen
echo "Success scaffolding"
