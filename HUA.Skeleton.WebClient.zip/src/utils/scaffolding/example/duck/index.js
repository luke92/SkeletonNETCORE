﻿// index.js
import exampleReducer from './ExampleReducers';
export { default as exampleOperations } from './ExampleOperations';
export { default as exampleTypes } from './ExampleTypes';
export default exampleReducer;