﻿//These strings are exported as an object literal which can then be
//imported into your reducers and action creators instead of hard -
//coding them
const EXAMPLE_ACTION_TYPE = 'EXAMPLE_ACTION_TYPE';
const FINISH_ACTION_TYPE = 'FINISH_ACTION_TYPE';

export default {
    EXAMPLE_ACTION_TYPE,
    FINISH_ACTION_TYPE
}