﻿// reducers.js
import types from './ExampleTypes';

const INITIAL_STATE = {
    examples: []
}

const exampleReducer = (state = INITIAL_STATE, action) => {
    var oldState = { ...state }
    switch (action.type) {

        case types.EXAMPLE_ACTION_TYPE:
            {
                console.log('Example action type execute');
                return oldState;
            }

        case types.FINISH_ACTION_TYPE:
            {
                let newState = Object.assign({},
                    oldState,
                    {
                        examples: action.value
                    });
                return newState;
            }

        default: return state;
    }
}

export default exampleReducer;