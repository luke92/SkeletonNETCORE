﻿//All action creators must be functions that return an object 
//with at least the type property.We do not define any async
//logic in this file.
import types from './ExampleTypes.js';

const exampleAction = () => {
    return {
        type: types.EXAMPLE_ACTION_TYPE
    }
};

const exampleFinishAction = (value) => {
    return {
        type: types.FINISH_ACTION_TYPE,
        value: value
    }
};

export default {
    exampleAction,
    exampleFinishAction
}