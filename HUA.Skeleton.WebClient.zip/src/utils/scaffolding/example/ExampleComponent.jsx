﻿// ExampleComponent.jsx
import React from 'react';

class ExampleComponent extends React.Component {

    render() {
        return (<h1>example component</h1>)
    }

}

export default ExampleComponent;