﻿import { connect } from 'react-redux';
import { exampleOperations } from './duck';

import ExampleComponent from './ExampleComponent';


class ExampleContainer extends ExampleComponent {

    constructor(props) {
        super(props);
    }

}

const mapStateToProps = (state) => {
    return {}
};

const mapDispatchToProps = (dispatch) => {
    return {};
};

export default connect(mapStateToProps, mapDispatchToProps)(ExampleContainer);