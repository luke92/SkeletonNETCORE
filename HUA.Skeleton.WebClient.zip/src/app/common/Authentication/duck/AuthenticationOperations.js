import Creator from './AuthenticationActions';

const loginAuto = () => {

    // Token temporal hasta que se encuentre implementado el nuevo sistema de autenticaión de Seguridad
    var token =
        "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IlNrZWxldG9uIiwiaHR0cDovL3NjaGVtYXMubWljcm9zb2Z0LmNvbS93cy8yMDA4LzA2L2lkZW50aXR5L2NsYWltcy9leHBpcmF0aW9uIjoxfQ.xsKMCPfjpVsvhVvXnQBWClyKnhyw7C6lW9q4X7iquRk";

    return dispatch => {
        dispatch(Creator.getActionLoginAuto({token: token}));
    }
};

export default {
    loginAuto
}




//import { executeApiCall } from '../api/apiProxy';

/*
export function loginAction(documentoTipo, documentoNumero, password) {
    return dispatch => {
        return new Promise((resolve, reject) => {
            dispatch({ type: Constants.ActionTypes.LOGIN_STARTED });

            executeApiCall('Authentication/login', 'POST', {
                tipoDeDocumentoId: documentoTipo,
                numeroDeDocumento: documentoNumero,
                password: password
            })
            .then(
                (response) => {
                    dispatch({ type: Constants.ActionTypes.LOGIN_SUCCED, payload: response });
                    resolve(response);
                },
                (response) => {
                    dispatch({ type: Constants.ActionTypes.LOGIN_FAILED, payload: response });
                    reject(response);
                }
            );
        });
    }
}

export function logoutAction() {
    return dispatch => {
        dispatch({ type: Constants.ActionTypes.LOGOUT });
    }
} */