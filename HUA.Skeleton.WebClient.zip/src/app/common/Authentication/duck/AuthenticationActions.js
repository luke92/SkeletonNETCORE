﻿import types from './AuthenticationTypes';

const getActionLoginSuccess = (value) => {
    return {
        type: types.AUTHENTICATION_LOGIN_SUCCED,
        payload: value
    }
};

const getActionLoginAuto = (value) => {
    return {
        type: types.AUTHENTICATION_LOGIN_AUTO,
        payload: value
    }
};

export default {
    getActionLoginSuccess,
    getActionLoginAuto
}