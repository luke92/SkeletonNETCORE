﻿// NavBarComponent.jsx
import React from 'react';

// React-Boostrap
import Navbar from 'react-bootstrap/lib/Navbar';
import Nav from 'react-bootstrap/lib/Nav';
import Button from 'react-bootstrap/lib/Button';

function NavBarComponent({}) {
    return (
        <Navbar bg="light" expand="lg">
            <Navbar.Brand href="home"> <img src="static/images/header_logo.png" height="50" /></Navbar.Brand>
            <Navbar.Toggle aria-controls="basic-navbar-nav" />
            <Navbar.Collapse id="basic-navbar-nav">
                <Nav className="mr-auto">
                    <Nav.Link href="home">Home</Nav.Link>
                    <Nav.Link href="users">Users</Nav.Link>
                </Nav>
                <Button variant="outline-primary" href="home">LOGIN</Button>
            </Navbar.Collapse>
        </Navbar>
    )
}

export default NavBarComponent;