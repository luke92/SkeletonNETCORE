﻿import { connect } from 'react-redux';
import NavBarComponent from './NavBarComponent';

const mapStateToProps = state => {
    return { }
};

const mapDispatchToProps = dispatch => {

    return {
    }
};

const NavBarContainer = connect(
    mapStateToProps,
    mapDispatchToProps
)(NavBarComponent);

export default NavBarContainer;