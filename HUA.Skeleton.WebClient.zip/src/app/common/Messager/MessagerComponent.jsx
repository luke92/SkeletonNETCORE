import React from 'react';

import { ToastContainer, toast, ToastType } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import types from './duck/MessagerTypes';

class MessagerComponent extends React.Component {

    
    getToastType(type) {
        switch (type) {
            case types.MESSAGER_SHOW_SUCCESS:
                return toast.TYPE.SUCCESS;
                break;
            case types.MESSAGER_SHOW_INFO:
                return toast.TYPE.INFO;
                break;
            case types.MESSAGER_SHOW_WARNING:
                return toast.TYPE.WARNING;
                break;
            case types.MESSAGER_SHOW_ERROR:
                return toast.TYPE.ERROR;
                break;
            default:
                return toast.TYPE.DEFAULT;
                break;
        }
    }

    render() {
        const { messageType, messages } = this.props;

        if (messages == undefined) {
            return (<span></span>);
        }

        messages.forEach(message => {
            toast(message.message, { type: this.getToastType(messageType) });
        });

        return (

            <ToastContainer
                position="bottom-center"
                autoClose={15000}
                hideProgressBar={false}
                newestOnTop
                closeOnClick
                rtl={false}
                pauseOnVisibilityChange
                draggable
                pauseOnHover
            />

        );
    }
}

export default (MessagerComponent);