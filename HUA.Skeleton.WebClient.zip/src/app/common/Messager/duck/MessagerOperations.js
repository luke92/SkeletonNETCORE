import Creator from './MessagerActions';
import types from './MessagerTypes';

const getActionError = Creator.getActionError;

const showError = (value) => {
    return dispatch => { 
        dispatch(getActionError(value));
    }
};

const showInfo = (value) => {
    return dispatch => {
        dispatch(Creator.geActionInfo(value));
    }
};

const showWarning = (value) => {
    return dispatch => {
        dispatch(Creator.getActionWarning(value));
    }
};

const showSuccess = (value) => {
    return dispatch => {
        dispatch(Creator.getActionSuccess(value));
    }
};

export default {
    showError,
    showInfo,
    showWarning,
    showSuccess
}