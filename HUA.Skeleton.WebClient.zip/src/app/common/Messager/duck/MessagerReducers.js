﻿import types from './MessagerTypes';

var defaultState = {
    open: false,
    messages: []
};

const MessagerReducer = (state = defaultState, action) => {
    var oldState = { ...state };
    let newState = {};

    switch (action.type) {

        case types.MESSAGER_SHOW_SUCCESS:
            newState = Object.assign({},
                oldState,
                {
                    messages: action.payload,
                    types: types.MESSAGER_SHOW_SUCCESS,
                    open: true
                });
            break;

        case types.MESSAGER_SHOW_INFO:
            newState = Object.assign({},
                oldState,
                {
                    messages: action.payload,
                    types: types.MESSAGER_SHOW_INFO,
                    open: true
                });
            break;

        case types.MESSAGER_SHOW_WARNING:
            newState = Object.assign({},
                oldState,
                {
                    messages: action.payload,
                    types: types.MESSAGER_SHOW_WARNING,
                    open: true
                });
            break;

        case types.MESSAGER_SHOW_ERROR:
            newState = Object.assign({},
                oldState,
                {
                    messages: action.payload,
                    types: types.MESSAGER_SHOW_ERROR,
                    open: true
                });
            break;
    }

    return newState;
}

export default MessagerReducer;