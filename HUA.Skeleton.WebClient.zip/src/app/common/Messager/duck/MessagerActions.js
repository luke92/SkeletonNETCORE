﻿import types from './MessagerTypes';

const getActionError = (value) => {
    return {
        type: types.MESSAGER_SHOW_ERROR,
        payload: value
    }
};

const getActionInfo = (value) => {
    return {
        type: types.MESSAGER_SHOW_INFO,
        payload: value
    }
};

const getActionWarning = (value) => {
    return {
        type: types.MESSAGER_SHOW_WARNING,
        payload: value
    }
};

const getActionSuccess = (value) => {
    return {
        type: types.MESSAGER_SHOW_SUCCESS,
        payload: value
    }
};

export default {
    getActionError,
    getActionInfo,
    getActionWarning,
    getActionSuccess
}