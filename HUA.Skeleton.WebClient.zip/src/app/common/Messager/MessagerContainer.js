import PropTypes from 'prop-types';
import 'react-toastify/dist/ReactToastify.css';
import types from './duck/MessagerTypes';
import MessagerComponent from './MessagerComponent'

class MessagerContainer extends MessagerComponent {

}

MessagerContainer.propTypes = {
    messageType: PropTypes.oneOf([
        types.MESSAGER_SHOW_ERROR,
        types.MESSAGER_SHOW_INFO,
        types.MESSAGER_SHOW_WARNING,
        types.MESSAGER_SHOW_SUCCESS]),
    messages: PropTypes.array
}

export default (MessagerContainer);