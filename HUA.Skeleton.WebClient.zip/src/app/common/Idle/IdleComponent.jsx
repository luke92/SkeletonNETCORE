import React from 'react';
import { Modal, Button } from 'react-bootstrap';
import IdleTimer from 'react-idle-timer';

class IdleComponent extends React.Component {

    render() {

        const { timeLeft } = this.state;
        const { minutesToIdle } = this.props;

        return (
            <div>
                <IdleTimer ref={ref => { this.idleTimer = ref }}
                    element={document}
                    onIdle={this.onIdle}
                    timeout={1000 * 60 * minutesToIdle}>
                    <Modal show={this.state.open}>
                        <Modal.Header closeButton>
                            <Modal.Title>Tiempo de inactividad</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            <p>Se ha detectado que no has tenido actividad en la web desde hace {minutesToIdle} minutos.
                                <br></br>¿Desea continuar conectado? Tienes <b> {timeLeft} </b> segundos para tomar una acción.
                            </p>
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="danger" onClick={this.handleClose}>Cerrar Sesión</Button>
                            <Button variant="link" onClick={this.handleNext}>Continuar</Button>
                        </Modal.Footer>
                    </Modal>
                </IdleTimer>
            </div>
        );
    }
}

export default IdleComponent