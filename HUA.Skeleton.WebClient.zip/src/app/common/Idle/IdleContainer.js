import PropTypes from 'prop-types';
import IdleComponent from './IdleComponent';

class IdleContainer extends IdleComponent {

    constructor() {

        super();

        this.state = {
            open: false,
            timerId: null
        };

        this.idleTimer = null;
        this.onIdle = this._onIdle.bind(this);
        this.timer = this.timer.bind(this);
    }

    componentDidMount() {

        this.setState({ timeLeft: this.props.secondsToAction });
    }

    timer() {
        if (this.state.timeLeft == 1) {
            this.handleClose();
        } else {
            this.setState({ timeLeft: this.state.timeLeft - 1 });
        }
    }

    _onIdle(e) {
        this.setState({ open: true, timerId: setInterval(this.timer, 1000) });
    }

    clearTimer() {
        this.setState({ open: false, timeLeft: this.props.secondsToAction });
        clearInterval(this.state.timerId);
    }

    handleClose = () => {
        this.clearTimer();
        this.props.logoutAction();
    };

    handleNext = () => {
        this.clearTimer();
    };
}

IdleContainer.propTypes = {
    secondsToAction: PropTypes.number.isRequired,
    minutesToIdle: PropTypes.number.isRequired,
    logoutAction: PropTypes.func.isRequired
};

export default IdleContainer