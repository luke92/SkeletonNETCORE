﻿import Creators from './ErrorActions';


const sendError = () => {
    return dispatch => {
        return fetch(process.env.API_APP_URL + 'api/User/')
            .then(response => response.json())
            .then(json => {
                dispatch(Creators.getActionErrorSended());
            });
    }
};

export default {
    sendError
}