﻿//All action creators must be functions that return an object 
//with at least the type property.We do not define any async
//logic in this file.
import types from './ErrorTypes';

const getActionSendingError = () => {
    return {
        type: types.ERROR_SEND_STARTED
    }
};

const getActionErrorSended = () => {
    return {
        type: types.ERROR_SEND_SUCCED
    }
};

export default {
    getActionSendingError,
    getActionErrorSended
}