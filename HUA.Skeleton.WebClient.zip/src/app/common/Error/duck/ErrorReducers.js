﻿import types from './ErrorTypes';

var defaultState = {
};

const ErrorReducers = (state = defaultState, action) => {
    var newState = { ...state };

    switch (action.type) {
/*
        case types.ERROR_SEND_STARTED:
            newState = {
                types: types.ERROR_SEND_STARTED,
            };
            break; */

        case types.ERROR_SEND_SUCCED:
            newState = {
                types: types.ERROR_SEND_SUCCED
            };
            break;
    }

    return newState;
}

export default ErrorReducers;