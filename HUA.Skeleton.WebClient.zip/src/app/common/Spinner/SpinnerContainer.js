import PropTypes from 'prop-types';
import SpinnerComponent from './SpinnerComponent';

class SpinnerContainer extends SpinnerComponent {

}

SpinnerContainer.propTypes = {
    show: PropTypes.bool.isRequired
};

export default SpinnerContainer