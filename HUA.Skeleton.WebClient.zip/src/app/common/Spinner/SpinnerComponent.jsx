import React from 'react';

class SpinnerComponent extends React.Component {

    render() {

        const { show } = this.props;

        return (<div className="loader">
            {show &&
                <div></div>
            }
        </div>
        );
    }
}

export default SpinnerComponent