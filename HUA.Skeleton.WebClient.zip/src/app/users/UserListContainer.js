﻿import { connect } from 'react-redux';

// This will make sense to you once we discuss the Redux code,
// but for now, just know that 'userOperations' will let you trigger 
// Redux actions.
import { usersOperations } from './duck';

import UserListComponent from './UserListComponent';


class UserListContainer extends UserListComponent {

    constructor(props) {
        super(props);
        this.state = {
            imgUsers: [
                "https://picsum.photos/200/100/?image=50",
                "https://picsum.photos/200/100/?image=91",
                "https://picsum.photos/200/100/?image=223",
                "https://picsum.photos/200/100/?image=31",
                "https://picsum.photos/200/100/?image=122",
                "https://picsum.photos/200/100/?image=22"
            ]
        }
    }

    componentDidMount() {
        this.props.fetchUsers();
    }

}

const mapStateToProps = (state) => {
    const { users } = state.users;
    return {
        users
    }
};

const mapDispatchToProps = (dispatch) => {
    // 'fetchUsers()' will trigger fetching of JSON data from
    // the BE API and pushes the relevant data into the Redux store.
    const fetchUsers = () => {
        dispatch(usersOperations.fetchUsers())
    };

    return { fetchUsers };
};

export default connect(mapStateToProps, mapDispatchToProps)(UserListContainer);