﻿// UserComponent.jsx
import React from 'react';
import Moment from 'react-moment';
import 'moment/locale/es';

// React-Boostrap
import Card from 'react-bootstrap/lib/Card';
import Row from 'react-bootstrap/lib/Row';
import Container from 'react-bootstrap/lib/Container';
import Col from 'react-bootstrap/lib/Col';

function UserComponent({
    user,
    img
}) {
    return (
        <Container>
            <Row>
                <Col md={{ span: 12 }}>
                    <Card>
                        <Card.Img variant="top" src={img} />
                        <Card.Body>
                            <Card.Title>{user.name} {user.surName}</Card.Title>

                            <Card.Text>
                                <em>{user.rol}</em>
                                <br />
                                {user.description}
                            </Card.Text>
                        </Card.Body>
                        <Card.Footer>
                            <small className="text-muted">Miembro <Moment fromNow locale="es">{user.createdDate}</Moment></small>
                        </Card.Footer>
                    </Card>
                </Col>
            </Row>
        </Container>
    )
}

export default UserComponent;