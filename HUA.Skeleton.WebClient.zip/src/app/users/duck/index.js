﻿// index.js
import usersReducer from './UserReducers';
export { default as usersOperations } from './UserOperations';
export { default as usersTypes } from './UserTypes';
export default usersReducer;