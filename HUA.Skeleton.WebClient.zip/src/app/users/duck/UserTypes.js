﻿//These strings are exported as an object literal which can then be
//imported into your reducers and action creators instead of hard -
//coding them
const GET_ALL_USERS = 'GET_ALL_USERS';
const RECEIVE_ALL_USERS = 'RECEIVE_ALL_USERS';

export default {
    GET_ALL_USERS,
    RECEIVE_ALL_USERS
}