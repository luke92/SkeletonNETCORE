﻿//All action creators must be functions that return an object 
//with at least the type property.We do not define any async
//logic in this file.
import types from './UserTypes.js';

const getAllUsers = () => {
    return {
        type: types.GET_ALL_USERS
    }
};

const receiveAllUsers = (value) => {
    return {
        type: types.RECEIVE_ALL_USERS,
        value: value
    }
};

export default {
    getAllUsers,
    receiveAllUsers
}