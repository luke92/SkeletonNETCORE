﻿// reducers.js
import types from './UserTypes';

const INITIAL_STATE = {
    users: []
}

const usersReducer = (state = INITIAL_STATE, action) => {
    var oldState = { ...state }
    switch (action.type) {

        case types.GET_ALL_USERS:
            {
                return oldState;
            }

        case types.RECEIVE_ALL_USERS:
            {
                let newState = Object.assign({},
                    oldState,
                    {
                        users: action.value
                    });
                return newState;
            }

        default: return state;
    }
}

export default usersReducer;