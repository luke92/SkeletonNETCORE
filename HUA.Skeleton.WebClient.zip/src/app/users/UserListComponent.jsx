﻿// UserListComponent.jsx
import React from 'react';
import shortid from 'shortid';

import { default as User } from './UserComponent';
// React-Boostrap
import CardColumns from 'react-bootstrap/lib/CardColumns';
import Container from 'react-bootstrap/lib/Container';
import Row from 'react-bootstrap/lib/Row';

class UserListComponent extends React.Component {

    render() {
        let { users } = this.props;

        if (users == undefined) {
            users = [];
        }

        return (<Container>
            <Row>
                <h3>Usuarios</h3>
                <CardColumns>
                    {
                        users.map((value, index) => {
                            return <User user={value} img={this.state.imgUsers[index]} key={shortid.generate()} />
                        })
                    }
                </CardColumns>
            </Row>
        </Container>)
    }

}

export default UserListComponent;