﻿// @app/users/index.js
export { default as UserList } from './UserListContainer';