﻿// HomeComponent.jsx
import React from 'react';
import { Spinner } from './../common/Spinner';

class HomeComponent extends React.Component {

    render() {

        const { siteName } = this.state;

        return (<div>
            <h3> {siteName} </h3>

            <Spinner show = {true}> </Spinner>

        </div>)
    }

}

export default HomeComponent;