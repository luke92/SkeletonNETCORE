﻿import { connect } from 'react-redux';
import HomeComponent from './HomeComponent';
import messagerOperations  from './../common/Messager/duck/MessagerOperations';

class HomeContainer extends HomeComponent {

    constructor() {
        super();

        this.state = {
            siteName: 'Hola Mundo! Home Example'
        }
    }

    componentDidMount() {
        this.props.showError([{ message: 'Mensaje ERROR TEST'}]);
    }

}

export default connect(
    state => {
        return {
            authentication: state.authentication
        };
    }
    , {
        showError : messagerOperations.showError
    })
    (HomeContainer);