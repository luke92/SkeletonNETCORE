﻿import Creators from './HomeActions';

const incrementCount = Creators.incrementCount;
const decrementCount = Creators.decrementCount;

export default {
    incrementCount,
    decrementCount
}