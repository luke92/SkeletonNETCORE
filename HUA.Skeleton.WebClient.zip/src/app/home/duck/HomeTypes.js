﻿//These strings are exported as an object literal which can then be
//imported into your reducers and action creators instead of hard -
//coding them
const INCREMENT_COUNT = 'INCREMENT_COUNT';
const DECREMENT_COUNT = 'DECREMENT_COUNT';

export default {
    INCREMENT_COUNT,
    DECREMENT_COUNT
}