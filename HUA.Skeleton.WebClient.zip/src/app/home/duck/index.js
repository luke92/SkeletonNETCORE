﻿// index.js
import homeReducer from './HomeReducers';
export { default as homeOperations } from './HomeOperations';
export { default as homeTypes } from './HomeTypes';
export default homeReducer;