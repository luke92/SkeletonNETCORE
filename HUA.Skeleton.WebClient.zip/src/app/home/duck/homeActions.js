﻿//All action creators must be functions that return an object 
//with at least the type property.We do not define any async
//logic in this file.
import types from './HomeTypes.js';

const incrementCount = (value) => {
    type: types.INCREMENT_COUNT,
    value
};

const decrementCount = (value) => {
    type: types.DECREMENT_COUNT,
    value
};
export default {
    incrementCount,
    decrementCount
}