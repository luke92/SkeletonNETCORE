﻿// CSS
import 'bootstrap/dist/css/bootstrap.css';
import '../../assets/styles/hua.common.scss';


import React, { Component } from 'react';
import { connect } from 'react-redux';
import {
    BrowserRouter as Router,
    Route,
    Redirect,
    Switch
} from 'react-router-dom';
import { Messager } from './common/Messager'

import { Home } from './home';
import { UserList } from './users';
import { NavBar } from './common/NavBar';
import { Idle } from './common/Idle';

import  authenticationOperations  from './common/Authentication/duck/AuthenticationOperations';
import errorOperations from './common/Error/duck/ErrorOperations';
import  messagerOperations  from './common/Messager/duck/MessagerOperations';

class App extends Component {

    constructor(props) {
        super(props);
        this.state = {
            subDirectory: document.getElementsByTagName('base')[0].getAttribute("href")
        };
    }

    componentDidCatch(error, errorInfo) {
        this.props.sendError({name: 'ReactJs', details: errorInfo});
        this.props.showError([{ message: 'Ocurrió un error, el mismo ha sivo enviado al servidor'}]);
    }

    componentWillMount(){

        // Verificamos si existe el token local para auto-loguearse
        this.props.loginAuto()
    }

    render() {

        const { messager, authentication, error } = this.props;

        return (<div>
            <Messager
                messages={messager.messages}
                messageType={messager.types}
            />
            <Router basename={this.state.subDirectory}>
                <div>
                    <NavBar />

                    <Switch>
                        <Route exact path='/' component={Home} />
                        <Route path='/home' component={Home} />
                        <Route path='/users' component={UserList} />
                        <Redirect from='*' to='/' />
                        {/* Add all your remaining routes here, like /trending, /about, etc. */}
                    </Switch>

                    {authentication.isAuthenticated &&
                        <Idle minutesToIdle={authentication.idleInMinutes} secondsToAction={60} logoutAction={() => { console.log('cierre') }} />}
                </div>
            </Router>
        </div>);
    }
}

export default connect(
    state => {
        return {
            authentication: state.authentication,
            messager: state.messager,
        }
    },
    {
        loginAuto : authenticationOperations.loginAuto,
        sendError : errorOperations.sendError,
        showError: messagerOperations.showError
    }
)(App);