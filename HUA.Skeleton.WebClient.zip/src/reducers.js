﻿import { combineReducers } from 'redux';
import homeReducer from './app/home/duck';
import usersReducer from './app/users/duck';
import messagerReducer from './app/common/Messager/duck';
import authenticationReducer from './app/common/Authentication/duck';
import errorReducer from './app/common/Error/duck'

const rootReducer = combineReducers({
    home: homeReducer,
    messager: messagerReducer,
    users: usersReducer,
    authentication: authenticationReducer,
    error: errorReducer
});

export default rootReducer;