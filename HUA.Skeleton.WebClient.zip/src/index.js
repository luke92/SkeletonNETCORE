﻿import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';

// redux-logger is a middleware that lets you log every state change
import logger from 'redux-logger';

// redux-thunk is a middleware that lets you dispatch async actions
import thunk from 'redux-thunk';
import {
    createStore,
    applyMiddleware
} from 'redux';
import App from './app/app';
import rootReducer from './reducers';

const middleware = applyMiddleware(thunk, logger);
const store = createStore(rootReducer, middleware);


if (module.hot && process.env.NODE_ENV == 'development') {
    module.hot.accept();
}

ReactDOM.render(
    <Provider store={store}>
    <App />
    </Provider>,
    document.getElementById('app')
);