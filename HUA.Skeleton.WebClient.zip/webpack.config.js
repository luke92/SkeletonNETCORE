﻿/// <binding ProjectOpened='Watch - Development' />
var path = require('path');
var webpack = require('webpack');
const CleanWebpackPlugin = require('clean-webpack-plugin');
const Dotenv = require('dotenv-webpack');

module.exports = {
    entry: { main: './src/index.js' },
    mode: 'development',
    output: {
        path: path.resolve(__dirname, "./wwwroot/static/scripts"),
        publicPath: 'static/scripts/',
        filename: 'app.js'
    },
    devServer: {
        historyApiFallback: {
            index: '/index.html'
        },
        hot: true,
        stats: 'errors-only',
        clientLogLevel: 'error'
    },
    plugins: [
        new CleanWebpackPlugin(
            [
                path.resolve(__dirname, "./wwwroot/static/scripts")
            ]
        ),
        new Dotenv({
            path: './.env'
        }),
        new webpack.NamedModulesPlugin()
    ],
    module: {
        rules: [
            {
                test: /.(jsx|js)?$/,
                exclude: /node_modules/,
                resolve: {
                    extensions: [".js", ".jsx"]
                },
                use: [
                    {
                        loader: 'babel-loader',
                        options: {
                            presets: ["react", "es2015", "stage-2"]
                        }
                    }
                ],
            },
            {
                test: /\.css$/,
                use: [
                    { loader: 'style-loader' },
                    { loader: 'css-loader' }
                ],
            },
            {
                test: /\.scss$/,
                use: [
                    process.env.NODE_ENV !== 'production' ? 'style-loader' : MiniCssExtractPlugin.loader, // creates style nodes from JS strings
                    "css-loader", // translates CSS into CommonJS
                    "sass-loader" // compiles Sass to CSS, using Node Sass by default
                ]
            },
            {
                test: /\.woff(\?v=\d+\.\d+\.\d+)?$/,
                use: "url-loader?limit=10000&mimetype=application/font-woff"
            },
            {
                test: /\.woff2(\?v=\d+\.\d+\.\d+)?$/,
                use: "url-loader?limit=10000&mimetype=application/font-woff"
            },
            {
                test: /\.ttf(\?v=\d+\.\d+\.\d+)?$/,
                use: "url-loader?limit=10000&mimetype=application/octet-stream"
            },
            {
                test: /\.eot(\?v=\d+\.\d+\.\d+)?$/,
                use: "file-loader"
            },
            {
                test: /\.svg(\?v=\d+\.\d+\.\d+)?$/,
                use: "url-loader?limit=10000&mimetype=image/svg+xml"
            }
        ]
    }
};